document.querySelector('#hit').addEventListener('click', () => window.open('https://example.com/old-landing-page'));
